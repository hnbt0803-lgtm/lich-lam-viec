LỊCH LÀM VIỆC — PHIÊN BẢN 1

1. Mở index.html để thử trên máy tính (dữ liệu chỉ lưu trên trình duyệt).
2. Tạo repository GitHub riêng (ví dụ sekai-scheduler), tải index.html lên và bật Settings > Pages > Deploy from branch > main > root.
3. Mở đường dẫn GitHub Pages trên iPhone và laptop.
4. Để đồng bộ: tạo Firebase project mới, bật Authentication > Email/Password và Firestore; sao chép firebaseConfig của Web App vào đầu index.html thay cho null.
5. QUAN TRỌNG: Trước khi dùng chung, phải bổ sung Firebase Security Rules và phân quyền. Bản mẫu hiện dùng một tài liệu dữ liệu chung, chưa phân quyền theo từng nhân viên. KHÔNG sử dụng dữ liệu nhân viên thật hoặc chia sẻ đường dẫn công khai trước khi cấu hình bảo mật.
6. Mở website trên iPhone Safari > Chia sẻ > Thêm vào màn hình chính.

Lưu ý: Dữ liệu nhân viên mẫu chỉ minh họa. Nhập nhân sự thật, lịch đăng ký và định biên trước khi xếp lịch. Thuật toán phiên bản 1 là heuristic, không đảm bảo luôn tìm ra lịch tối ưu hoặc đạt mọi ưu tiên.
